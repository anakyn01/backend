function CheckAddProduct(){
	var bookID = document.getElementById("bookID");
	var bookName = document.getElementById("bookName");
	var unitPrice = document.getElementById("unitPrice");
	var unitsInStock = document.getElementById("unitsInStock");
}

//도서 아이디 체크
if (!check(/^P[0-9]{4,11}$/, bookID,"[도서 코드]\nP와 숫자를 조합하여 5~12자까지 입력하세요\n첫 글자는 반드시 P로 시작하세요"))
	return false;
	       							
//도서명 체크 